'use strict';

var _jQuery = jQuery.noConflict(true),
    _jqLiteMode = true;
